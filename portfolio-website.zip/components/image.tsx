"use client"

import { useState } from "react"

interface ImageProps {
  src: string
  alt: string
  className?: string
  width?: number
  height?: number
}

export function Image({ src, alt, className, width, height }: ImageProps) {
  const [isLoaded, setIsLoaded] = useState(false)

  return (
    <img
      src={src || "/placeholder.svg"}
      alt={alt}
      className={`${className} ${isLoaded ? "opacity-100" : "opacity-0"}`}
      width={width}
      height={height}
      onLoad={() => setIsLoaded(true)}
      style={{ transition: "opacity 0.3s" }}
    />
  )
}
