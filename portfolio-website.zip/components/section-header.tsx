interface SectionHeaderProps {
  title: string
}

export function SectionHeader({ title }: SectionHeaderProps) {
  return (
    <div className="mb-8">
      <h2 className="text-3xl font-bold gradient-text inline-block">{title}</h2>
      <div className="marriott-divider w-32 mt-2"></div>
    </div>
  )
}
