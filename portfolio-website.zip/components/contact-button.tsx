"use client"

import type React from "react"

import { Mail } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function ContactButton() {
  const [copied, setCopied] = useState(false)
  const email = "kalenzijimmy8@gmail.com"

  const handleClick = () => {
    window.location.href = `mailto:${email}`
  }

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation()
    navigator.clipboard.writeText(email)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            onClick={handleClick}
            variant="outline"
            className="flex items-center gap-2 border-secondary/50 text-secondary hover:bg-secondary/10 group"
          >
            <Mail className="h-4 w-4 group-hover:text-secondary transition-colors" />
            <span className="group-hover:text-secondary transition-colors">Contact via Email</span>
            <span
              onClick={handleCopy}
              className="ml-2 text-xs bg-primary/10 text-primary px-2 py-1 rounded cursor-pointer hover:bg-primary/20"
            >
              {copied ? "Copied!" : "Copy"}
            </span>
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Send an email to {email}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
