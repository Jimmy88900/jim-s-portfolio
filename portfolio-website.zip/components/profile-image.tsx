"use client"

import { useState } from "react"
import { ImageWithFallback } from "./image-with-fallback"

export function ProfileImage() {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className="relative w-64 h-64 rounded-full overflow-hidden border-4 border-secondary/70 group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div
        className={`absolute inset-0 bg-gradient-to-b from-primary/0 to-primary/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6 z-10`}
      >
        <span className="text-white font-medium">Kalenzi Jimmy</span>
      </div>
      <ImageWithFallback
        src="/images/profile-photo.png"
        alt="Kalenzi Jimmy"
        className={`object-cover w-full h-full transition-transform duration-500 ${
          isHovered ? "scale-110" : "scale-100"
        }`}
        width={256}
        height={256}
      />
    </div>
  )
}
