import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

export function MarriottHeader() {
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur">
      <div className="container flex h-20 items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center">
            <span className="text-primary-foreground font-serif text-xl">M</span>
          </div>
          <div>
            <div className="font-bold text-xl">Kalenzi Jimmy</div>
            <div className="text-xs text-muted-foreground">IT Support Specialist</div>
          </div>
        </div>

        <nav className="hidden md:flex gap-6">
          <Link href="#about" className="text-muted-foreground hover:text-foreground transition-colors">
            About
          </Link>
          <Link href="#experience" className="text-muted-foreground hover:text-foreground transition-colors">
            Experience
          </Link>
          <Link href="#skills" className="text-muted-foreground hover:text-foreground transition-colors">
            Skills
          </Link>
          <Link href="#education" className="text-muted-foreground hover:text-foreground transition-colors">
            Education
          </Link>
          <Link href="#contact" className="text-muted-foreground hover:text-foreground transition-colors">
            Contact
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          <ThemeToggle />
          <Button asChild variant="default" className="bg-primary hover:bg-primary/90">
            <Link href="#contact">Get in Touch</Link>
          </Button>
        </div>
      </div>
      <div className="marriott-divider w-full"></div>
    </header>
  )
}
