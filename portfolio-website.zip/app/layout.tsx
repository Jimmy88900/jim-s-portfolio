import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Kalenzi Jimmy - IT Support Specialist",
  description:
    "Portfolio website for Kalenzi Jimmy, an IT Support Specialist with expertise in Network & Systems Administration, Hospitality Tech, and Cybersecurity.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
        <script
          dangerouslySetInnerHTML={{
            __html: `
            document.addEventListener('DOMContentLoaded', function() {
              const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                  if (entry.isIntersecting) {
                    entry.target.classList.add('animate-slide-up');
                    observer.unobserve(entry.target);
                  }
                });
              }, { threshold: 0.1 });
              
              document.querySelectorAll('section > div, section > .grid, section > .space-y-8, section > .space-y-6').forEach(el => {
                observer.observe(el);
              });
            });
          `,
          }}
        />
      </body>
    </html>
  )
}
