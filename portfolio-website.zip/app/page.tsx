import Link from "next/link"
import { Mail, Linkedin, Phone, MapPin, Download, Bed, Wifi, Key, CreditCard } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

import { AnimatedBackground } from "@/components/animated-background"
import { ContactButton } from "@/components/contact-button"
import { ProfileImage } from "@/components/profile-image"
import { MarriottHeader } from "@/components/marriott-header"
import { SectionHeader } from "@/components/section-header"

export default function Home() {
  return (
    <div className="min-h-screen bg-background marriott-pattern">
      <AnimatedBackground />

      <MarriottHeader />

      <main className="container py-10">
        {/* Hero Section */}
        <section className="py-12 md:py-20 flex flex-col md:flex-row gap-8 items-center">
          <div className="md:w-1/2 space-y-6 animate-slide-in-right">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight gradient-text">IT Support Specialist</h1>
            <p className="text-xl text-muted-foreground">
              Network & Systems Admin | Hospitality Tech | PMS/POS | Wi-Fi/IPTV | Cybersecurity | Guest Tech
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button asChild size="lg" className="hover-lift bg-primary hover:bg-primary/90">
                <Link href="#contact">Contact Me</Link>
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="hover-lift border-secondary text-secondary hover:text-secondary hover:bg-secondary/10"
              >
                <Download className="mr-2 h-4 w-4" /> Download CV
              </Button>
            </div>
            <div className="mt-4">
              <ContactButton />
            </div>
            <div className="flex gap-4 pt-4">
              <Link
                href="mailto:kalenzijimmy8@gmail.com"
                className="text-muted-foreground hover:text-secondary transition-colors duration-300"
              >
                <Mail className="h-5 w-5" />
                <span className="sr-only">Email</span>
              </Link>
              <Link
                href="https://www.linkedin.com/in/kalenzi-jimmy-709258191"
                className="text-muted-foreground hover:text-foreground transition-colors duration-300"
              >
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Link>
              <Link
                href="tel:0751621120"
                className="text-muted-foreground hover:text-foreground transition-colors duration-300"
              >
                <Phone className="h-5 w-5" />
                <span className="sr-only">Phone</span>
              </Link>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center animate-fade-in">
            <ProfileImage />
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-12 scroll-mt-20">
          <SectionHeader title="About Me" />
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="md:col-span-2 border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
              <CardContent className="pt-6">
                <p className="text-muted-foreground leading-relaxed">
                  I'm an IT Support Specialist with a unique blend of experience in hospitality, clinical research, and
                  public health sectors. At Sheraton Kampala Hotel, I ensure seamless operations across guest-facing
                  technologies — from Wi-Fi and IPTV to PMS, POS, and key card systems — to create memorable,
                  tech-enabled guest experiences.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  My core strengths lie in troubleshooting complex system issues, optimizing network performance, and
                  managing IT inventory and compliance. I've also supported clinical trial data systems at MRC/UVRI and
                  taught foundational IT skills in healthcare training programs. I thrive where technology and people
                  intersect — solving problems, improving uptime, and supporting smooth daily operations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  As I pursue my next role before the end of 2025, I'm looking for opportunities where I can support
                  enterprise systems, contribute to digital transformation, and continue growing my network and security
                  administration skills.
                </p>
              </CardContent>
            </Card>
            <Card className="border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium">Location</h3>
                    <p className="text-muted-foreground flex items-center mt-1">
                      <MapPin className="h-4 w-4 mr-2 text-secondary" /> Kampala, Uganda
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium">Email</h3>
                    <p className="text-muted-foreground mt-1">
                      <Link
                        href="mailto:kalenzijimmy8@gmail.com"
                        className="hover:text-secondary transition-colors duration-300"
                      >
                        kalenzijimmy8@gmail.com
                      </Link>
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium">Phone</h3>
                    <p className="text-muted-foreground mt-1">
                      <Link href="tel:0751621120" className="hover:text-foreground">
                        0751621120
                      </Link>
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium">LinkedIn</h3>
                    <p className="text-muted-foreground mt-1">
                      <Link
                        href="https://www.linkedin.com/in/kalenzi-jimmy-709258191"
                        className="hover:text-foreground"
                      >
                        linkedin.com/in/kalenzi-jimmy-709258191
                      </Link>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Experience Section */}
        <section id="experience" className="py-12 scroll-mt-20">
          <SectionHeader title="Work Experience" />
          <div className="space-y-8">
            <Card className="hover-lift hover:shadow-lg transition-all duration-300 border-secondary/20 hover:border-secondary/40">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold">IT Support Specialist</h3>
                    <p className="text-secondary">Sheraton Kampala Hotel</p>
                  </div>
                  <div className="text-muted-foreground">April 2023 - Present (2 years 2 months)</div>
                </div>
                <p className="text-muted-foreground mb-4">Kampala, Central Region, Uganda</p>
                <div className="flex flex-wrap gap-3 mb-4">
                  <Badge className="bg-primary/10 text-primary hover:bg-primary/20 flex items-center gap-1">
                    <Bed className="h-3 w-3" /> PMS
                  </Badge>
                  <Badge className="bg-primary/10 text-primary hover:bg-primary/20 flex items-center gap-1">
                    <CreditCard className="h-3 w-3" /> POS
                  </Badge>
                  <Badge className="bg-primary/10 text-primary hover:bg-primary/20 flex items-center gap-1">
                    <Wifi className="h-3 w-3" /> Wi-Fi/IPTV
                  </Badge>
                  <Badge className="bg-primary/10 text-primary hover:bg-primary/20 flex items-center gap-1">
                    <Key className="h-3 w-3" /> Key Card Systems
                  </Badge>
                </div>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>Manage PMS, POS, IPTV, key card access, and guest Wi-Fi systems in a 5-star environment</li>
                  <li>Deliver end-user and guest support for hardware, software, and network troubleshooting</li>
                  <li>Maintain system uptime, perform backups, and enforce IT compliance</li>
                  <li>Coordinate with vendors and departments to ensure continuous tech-driven guest services</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover-lift hover:shadow-lg transition-all duration-300 border-secondary/20 hover:border-secondary/40">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold">Data Manager Assistant</h3>
                    <p className="text-secondary">MRC/UVRI Uganda Research Unit on AIDS</p>
                  </div>
                  <div className="text-muted-foreground">August 2022 - March 2023 (8 months)</div>
                </div>
                <p className="text-muted-foreground mb-4">Entebbe, Wakiso, Uganda</p>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>Supported clinical trial data management and electronic records</li>
                  <li>Validated, cleaned, and maintained large health data sets and ensured system backup integrity</li>
                  <li>Liaised with data teams and supervisors on quality control and reporting</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover-lift hover:shadow-lg transition-all duration-300 border-secondary/20 hover:border-secondary/40">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold">Information Technology Instructor</h3>
                    <p className="text-secondary">Masaka Regional Referral Hospital</p>
                  </div>
                  <div className="text-muted-foreground">April 2021 - December 2021 (9 months)</div>
                </div>
                <p className="text-muted-foreground mb-4">Masaka</p>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>Taught core IT principles to students and staff in a health training institute</li>
                  <li>Maintained lab systems, provided basic support, and developed training materials</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" className="py-12 scroll-mt-20">
          <SectionHeader title="Skills & Expertise" />
          <Tabs defaultValue="technical">
            <TabsList className="mb-6 bg-primary/10">
              <TabsTrigger
                value="technical"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Technical Skills
              </TabsTrigger>
              <TabsTrigger
                value="certifications"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Certifications & Tools
              </TabsTrigger>
              <TabsTrigger
                value="industries"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Industries
              </TabsTrigger>
            </TabsList>
            <TabsContent value="technical" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "100ms" }}
                >
                  Private Branch Exchange (PBX)
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "200ms" }}
                >
                  Asterisk (PBX)
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "300ms" }}
                >
                  CodeIgniter
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "400ms" }}
                >
                  Network Administration
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "500ms" }}
                >
                  System Administration
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "600ms" }}
                >
                  Troubleshooting
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "700ms" }}
                >
                  IT Support
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "800ms" }}
                >
                  Data Management
                </Badge>
              </div>
            </TabsContent>
            <TabsContent value="certifications" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "100ms" }}
                >
                  Windows Server
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "200ms" }}
                >
                  Active Directory
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "300ms" }}
                >
                  PMS/POS
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "400ms" }}
                >
                  Cisco
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "500ms" }}
                >
                  PBX
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "600ms" }}
                >
                  Asterisk
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "700ms" }}
                >
                  EMPOWER GXP
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "800ms" }}
                >
                  CCNA
                </Badge>
              </div>
            </TabsContent>
            <TabsContent value="industries" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "100ms" }}
                >
                  Hospitality
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "200ms" }}
                >
                  Research
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "300ms" }}
                >
                  Health
                </Badge>
                <Badge
                  className="justify-center py-3 text-sm animate-fade-in bg-primary/10 text-primary hover:bg-primary/20"
                  style={{ animationDelay: "400ms" }}
                >
                  Public Sector
                </Badge>
              </div>
            </TabsContent>
          </Tabs>
        </section>

        {/* Education Section */}
        <section id="education" className="py-12 scroll-mt-20">
          <SectionHeader title="Education" />
          <div className="space-y-6">
            <Card className="border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between mb-2">
                  <div>
                    <h3 className="text-xl font-bold">Uganda Christian University</h3>
                    <p className="text-secondary">Bachelor of Science in Information Technology</p>
                  </div>
                  <div className="text-muted-foreground">January 2016 - December 2020</div>
                </div>
                <p className="text-muted-foreground">Computer Systems Networking and Telecommunications</p>
              </CardContent>
            </Card>

            <Card className="border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between mb-2">
                  <div>
                    <h3 className="text-xl font-bold">APTECH Computer Education</h3>
                    <p className="text-secondary">Certificate, CCNA</p>
                  </div>
                  <div className="text-muted-foreground">2017 - 2017</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-12 scroll-mt-20">
          <SectionHeader title="Contact Me" />
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-4">Get In Touch</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-secondary mt-1" />
                    <div>
                      <p className="font-medium">Address</p>
                      <p className="text-muted-foreground">
                        Sheraton Kampala Hotel
                        <br />
                        Ternan Avenue
                        <br />
                        P.O. Box 7041
                        <br />
                        Kampala, Uganda
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="h-5 w-5 text-secondary mt-1" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <Link href="tel:0751621120" className="text-muted-foreground hover:text-foreground">
                        0751621120 (Mobile)
                      </Link>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Mail className="h-5 w-5 text-secondary mt-1" />
                    <div>
                      <p className="font-medium">Email</p>
                      <Link
                        href="mailto:kalenzijimmy8@gmail.com"
                        className="text-muted-foreground hover:text-secondary transition-colors duration-300 underline"
                      >
                        kalenzijimmy8@gmail.com
                      </Link>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Linkedin className="h-5 w-5 text-secondary mt-1" />
                    <div>
                      <p className="font-medium">LinkedIn</p>
                      <Link
                        href="https://www.linkedin.com/in/kalenzi-jimmy-709258191"
                        className="text-muted-foreground hover:text-foreground"
                      >
                        www.linkedin.com/in/kalenzi-jimmy-709258191
                      </Link>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
              <CardContent className="pt-6">
                <form className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Name
                      </label>
                      <input
                        id="name"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Your name"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <input
                        id="email"
                        type="email"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Your email"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="subject" className="text-sm font-medium">
                      Subject
                    </label>
                    <input
                      id="subject"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Subject"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Message
                    </label>
                    <textarea
                      id="message"
                      className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Your message"
                    />
                  </div>
                  <Button className="w-full bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 transition-all duration-300">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t py-6 md:py-0 bg-primary text-primary-foreground">
        <div className="marriott-divider w-full mb-6"></div>
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 md:h-16">
          <p className="text-sm">© {new Date().getFullYear()} Kalenzi Jimmy. All rights reserved.</p>
          <div className="flex gap-4">
            <Link
              href="mailto:kalenzijimmy8@gmail.com"
              className="text-primary-foreground/70 hover:text-secondary transition-colors duration-300"
            >
              <Mail className="h-5 w-5" />
              <span className="sr-only">Email</span>
            </Link>
            <Link
              href="https://www.linkedin.com/in/kalenzi-jimmy-709258191"
              className="text-primary-foreground/70 hover:text-secondary"
            >
              <Linkedin className="h-5 w-5" />
              <span className="sr-only">LinkedIn</span>
            </Link>
            <Link href="tel:0751621120" className="text-primary-foreground/70 hover:text-secondary">
              <Phone className="h-5 w-5" />
              <span className="sr-only">Phone</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
